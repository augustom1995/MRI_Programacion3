package Grafo;

public class NodoGrafo {
	public int valor;
	public NodoArista lista;
	public NodoGrafo sig;
	public boolean Visitado;
	public boolean marcado;
}
